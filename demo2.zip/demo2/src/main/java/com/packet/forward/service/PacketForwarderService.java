package com.packet.forward.service;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Service;

import com.packet.forward.config.RouterConfigProperties;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import javax.annotation.PostConstruct;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.LinkedBlockingQueue;

@Slf4j
@Service
@EnableScheduling
public class PacketForwarderService {

	@Value("${listner-port}")
	private Integer listnerPort;

	@Value("${packet-buffer-size}")
	private Integer packetBufferSize;

	private final RouterConfigProperties routerConfigProperties;

	// Dynamic thread pool that can scale with incoming packet load
	private final ExecutorService executorService = new ThreadPoolExecutor(
			10, // core pool size
			100, // maximum pool size
			60L, // keep-alive time
			java.util.concurrent.TimeUnit.SECONDS, 
			new LinkedBlockingQueue<>(1000)); // Blocking queue with capacity

	@Autowired
	public PacketForwarderService(RouterConfigProperties routerConfigProperties) {
		this.routerConfigProperties = routerConfigProperties;
	}

	@Async
	@Scheduled(fixedRate = 1000)
	public void startReceivePackets() {
		try (DatagramSocket dSock = new DatagramSocket(listnerPort)) {
			DatagramPacket dgramPkt = new DatagramPacket(new byte[packetBufferSize], packetBufferSize);

			while (true) {
				dSock.receive(dgramPkt);
				Integer targetPort = routerConfigProperties.getRoutes().get(dgramPkt.getAddress().getHostName());

				if (targetPort == null) {
					targetPort = routerConfigProperties.getDefaultPort();
				}

				// Forward packet asynchronously using the thread pool
				forwardToPort(dgramPkt, targetPort);
			}
		} catch (IOException e) {
			log.error("Error while receiving packet: " + e.getMessage(), e);
		}
	}

	// Forward the packet to the target port asynchronously
	private void forwardToPort(DatagramPacket datagramPacket, int port) {
		executorService.submit(() -> {
			try (DatagramSocket socket = new DatagramSocket()) {
				InetAddress targetAddress = InetAddress.getByName("localhost");

				DatagramPacket packet = new DatagramPacket(datagramPacket.getData(), datagramPacket.getData().length,
						targetAddress, port);

				socket.send(packet);
				log.info("Forwarded packet to port " + port);

			} catch (IOException e) {
				log.error("Failed to forward packet to port " + port, e);
			}
		});
	}
}
