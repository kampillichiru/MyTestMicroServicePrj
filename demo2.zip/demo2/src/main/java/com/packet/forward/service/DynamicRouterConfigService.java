package com.packet.forward.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.packet.forward.config.RouterConfigProperties;

@Service
public class DynamicRouterConfigService {

    private final RouterConfigProperties routerConfigProperties;

    @Autowired
    public DynamicRouterConfigService(RouterConfigProperties routerConfigProperties) {
        this.routerConfigProperties = routerConfigProperties;
    }

	/*
	 * public int getRouterPort(String routerName) { // Try to get the port for the
	 * given router name, otherwise return default return
	 * routerConfigProperties.getRouters().getOrDefault(routerName, new
	 * RouterConfigProperties.Router()) .getPort() != 0 ?
	 * routerConfigProperties.getRouters().get(routerName).getPort() :
	 * routerConfigProperties.getDefaultPort(); }
	 */
}
