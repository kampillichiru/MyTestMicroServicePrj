package com.packet.forward;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.scheduling.annotation.EnableAsync;

import com.packet.forward.config.RouterConfigProperties;


@EnableAsync
@SpringBootApplication
@EnableConfigurationProperties(RouterConfigProperties.class)
public class PacketForwardApplication{

	public static void main(String[] args) {
		SpringApplication.run(PacketForwardApplication.class, args);
	}

	
}
