package com.packet.forward.config;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "router-config")
public class RouterConfigProperties {

    private Map<String, Integer> routes;  // Map of router names to ports
    private int defaultPort;              // Default port if no matching router is found

    public Map<String, Integer> getRoutes() {
        return routes;
    }

    public void setRoutes(Map<String, Integer> routes) {
        this.routes = routes;
    }

    public int getDefaultPort() {
        return defaultPort;
    }

    public void setDefaultPort(int defaultPort) {
        this.defaultPort = defaultPort;
    }
}
